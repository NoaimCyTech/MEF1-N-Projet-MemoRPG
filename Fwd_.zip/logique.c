#include <stdio.h>
#include <string.h>
#include "logique.h"
#include "structure.h"


// 1. Fonction qui gère les règles du combat
// Renvoie 1 si le joueur gagne, 0 s'il perd
int resoudreCombat(char monstre[], int arme) {
    if (strcmp(monstre, "basilic") == 0 && arme == 1) return 1; // 1 = Bouclier
    if (strcmp(monstre, "zombie") == 0 && arme == 2) return 1;  // 2 = Torche
    if (strcmp(monstre, "troll") == 0 && arme == 3) return 1;   // 3 = Hache
    if (strcmp(monstre, "harpie") == 0 && arme == 4) return 1;  // 4 = Arc
    return 0; // Si aucune condition n'est remplie, c'est perdu
}

// 2. Fonction qui gère tout l'échange du Totem

void executerTotem(Case grille[5][5], Joueur heros[], int tourActuel) {
    int l2, c2;
    printf("\n🗿 TOTEM DE TRANSMUTATION ! Ton tour s'arrete ici.\n");

    do {
        printf("Choisis une case CACHEE (Ligne 0-4) : ");
        scanf("%d", &l2);
        printf("Choisis une case CACHEE (Colonne 0-4) : ");
        scanf("%d", &c2);
        if (grille[l2][c2].estCachee == 0) {
            printf("🚫 Erreur : Tu ne peux pas choisir une case deja revelee !\n");
        }
    } while (grille[l2][c2].estCachee == 0);

    // Échange des cases
    Case temp = grille[heros[tourActuel].ligne][heros[tourActuel].colonne];
    grille[heros[tourActuel].ligne][heros[tourActuel].colonne] = grille[l2][c2];
    grille[l2][c2] = temp;

    printf("✨ Les cartes ont ete echangees dans l'ombre...\n");
    // Retour à la base obligatoire
    if(tourActuel == 0) { 
        heros[tourActuel].ligne = -1; heros[tourActuel].colonne = 2; 
    }
    else if(tourActuel == 1) { 
        heros[tourActuel].ligne = 5; heros[tourActuel].colonne = 2; 
    }
    else if(tourActuel == 2) { 
        heros[tourActuel].ligne = 2; heros[tourActuel].colonne = -1; 
    }
    else { 
        heros[tourActuel].ligne = 2; heros[tourActuel].colonne = 5; 
    }

    // On recache tout le plateau
    for(int l = 0; l < 5; l++) {
        for(int c = 0; c < 5; c++) {
            grille[l][c].estCachee = 1;
        }
    }
}