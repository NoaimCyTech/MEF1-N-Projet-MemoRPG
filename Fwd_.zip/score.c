#include <stdio.h>
#include <string.h>
#include "score.h"
#include "structure.h"


typedef struct{
    char pseudo[50]; 
    int parties; 
    int victoires ;
}Historique; 


void sauvegarderScores(Joueur heros[], int nbJoueurs, char pseudoGagnant[]){
    Historique tousLesScores[100]; 
    int nbInscrits = 0 ; // Il va nous servir à savoir exactement combien de cases de ce tableau sont remplies.

    FILE *fichier = fopen("score.txt", "r"); // "r" pour Read (Lire)
    if(fichier !=NULL){
        while (fscanf(fichier, "%s %d %d", tousLesScores[nbInscrits].pseudo, &tousLesScores[nbInscrits].parties, &tousLesScores[nbInscrits].victoires) == 3) {
            // On lit l'ancien fichier ligne par ligne : Pseudo, Parties, Victoires
            nbInscrits++;

        }
        fclose(fichier);
    }

    // --- PHASE 2 : METTRE A JOUR AVEC LES JOUEURS DE CETTE PARTIE ---

    for(int i =0 ; i<nbJoueurs; i++){
        int joueurConnu = 0 ;

        // On cherche si le joueur de notre partie est déjà dans l'historique
        for(int j =0 ; j <nbInscrits ; j++){
            if (strcmp(heros[i].pseudo, tousLesScores[j].pseudo) == 0) {
                tousLesScores[j].parties += 1; // +1 partie jouée

                // Si ce joueur est le gagnant, +1 victoire !
                if (strcmp(heros[i].pseudo, pseudoGagnant) == 0) {
                    tousLesScores[j].victoires += 1;
                }
                joueurConnu = 1;
                break; // On a trouvé, on arrête de chercher
            }
        }
        if(joueurConnu == 0){
            strcpy(tousLesScores[nbInscrits].pseudo, heros[i].pseudo);
            tousLesScores[nbInscrits].parties = 1;
            if (strcmp(heros[i].pseudo, pseudoGagnant) == 0) {
                tousLesScores[nbInscrits].victoires = 1;
            } else {
                tousLesScores[nbInscrits].victoires = 0;
            }
            nbInscrits = nbInscrits + 1; // La liste s'agrandit d'une personne

        }
    }



    fichier = fopen("score.txt", "w"); // ecrire sa ecrase l ancienne version 
    if(fichier != NULL){
        for(int i = 0; i<nbInscrits; i++){
            fprintf(fichier, "%s %d %d\n", tousLesScores[i].pseudo, tousLesScores[i].parties, tousLesScores[i].victoires);
        }
        fclose(fichier);
        printf("Historique sauvegarde dans le donjon !\n");
    }
    else{
        printf("\n❌ Erreur : Impossible de sauvegarder.\n");
    }
        

}

