# M-MO-RPG
Projet CY-Memo-RPG 

Jeu de mémoire et de rôle (RPG) développé en langage C.


Filière : preING1 (2025-2026)   

Groupe : Sarah / Safa / Ranya 



L'objectif est d'explorer un labyrinthe de 25 cartes faces cachées  pour retrouver deux objets :  


L'Arme Antique propre à votre classe (Épée, Bâton, Grimoire ou Dague).  

Un Coffre au Trésor.  


Attention : Si vous perdez un combat contre un monstre, vous retournez au départ et tout le labyrinthe redevient masqué. La mémoire est votre seule alliée.


Installation et Lancement : 
Compiler le projet :

Utilisez le fichier Makefile pour automatiser la compilation de tous les modules :

Bash
make


Lancer le jeu :

Bash
./jeu.exe


 Guide des CombatsAvant de bouger, choisissez l'arme adaptée au monstre que vous risquez de croiser:  
 Bouclier 🛡️ contre le Basilic 🐍   
 Torche 🔥 contre le Zombie 🧟   
 Hache 🪓 contre le Troll 👹   
 Arc 🏹 contre la Harpie 🦅 


 Le projet respecte les contraintes de modularité demandées:  

main.c : Coeur du jeu et gestion des tours.

plateau.c : Génération aléatoire de la grille et affichage graphique (Emojis).

logique.c : Règles de combat et gestion des cases spéciales (Portail, Totem).


score.c : Gestion de la persistance des données dans un fichier .txt.  


Fonctionnalités Implémentées
Gestion de 2 à 4 joueurs avec pseudos personnalisés. 
 Symétrie radiale du positionnement des joueurs.  
 Cases spéciales : Portail magique (téléportation) et Totem (échange de cases).  
 Historique persistant : Sauvegarde du nombre de parties et des victoires.  
 Fin de partie : Révélation complète du labyrinthe.  