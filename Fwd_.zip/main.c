#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <windows.h> // Indispensable pour parler au terminal Windows

#include "menu.h"
#include "structure.h"
#include "plateau.h"
#include "logique.h"
#include "score.h"



int main(){
    SetConsoleOutputCP(65001); // 65001 est le code magique pour activer l'UTF-8
    int nbJoueurs ; 
    int nbMorts = 0; // Compteur pour savoir si toute l'équipe a perdu

    //  demande le nombre de joueur 
    do{
        printf("Combien d'aventuriers sont prets a entrer dans le donjon ? (Entre 2 et 4):");
        scanf("%d", &nbJoueurs);
        if(nbJoueurs < 2 || nbJoueurs > 4) {
            printf("Erreur : Il faut entre 2 et 4 joueurs !\n");
        }
    }while (nbJoueurs < 2 || nbJoueurs > 4);

    // je créer l'equipe 

    Joueur mesHeros[4]; // Je cree un tableau de 4 cases. Chaque case contient toutes les infos d'un joueur (pseudo, ligne, colonne...).(je creer donc 1 joueurs ans chaque case)

    for(int i = 0 ; i<nbJoueurs ; i++){
        printf("\nJoueurs %d , quel est ton pseudo ? : ", i+1); 
        scanf("%s", mesHeros[i].pseudo); // // On range le pseudo dans la structure
        mesHeros[i].armeAntiqueTrouvee = 0;
        mesHeros[i].tresorTrouve = 0;
        mesHeros[i].peutTeleporter = 0;
        // Placement autour du plateau de 5x5 (Symetrie radiale)

        if(i==0){ // Joueur 1 : En haut au milieu
            mesHeros[i].ligne = -1 ;  
            mesHeros[i].colonne = 2 ; 
        }
        else if(i==1){ // Joueur 2 : En bas au milieu
            mesHeros[i].ligne =  5 ; 
            mesHeros[i].colonne = 2 ; 
        }
        else if(i==2){ // Joueur 3 : A gauche au milieu
            mesHeros[i].ligne =  2 ; 
            mesHeros[i].colonne = -1 ; 
        }
        else{ // Joueur 4 : A droite au milieu
        
            mesHeros[i].ligne =  2 ; 
            mesHeros[i].colonne = 5 ;
        }
    }
    printf("\n--- L'equipe est prete ! Le jeu commence ! ---\n");

    printf("\n🛡️ RAPPEL DES MISSIONS :\n");
    for(int i = 0; i < nbJoueurs; i++) {
        if(i == 0) printf("- %s (Guerrier) cherche l'Epee de feu [🗡️]\n", mesHeros[i].pseudo);
        if(i == 1) printf("- %s (Ranger) cherche le Baton de controle [🪄]\n", mesHeros[i].pseudo);
        if(i == 2) printf("- %s (Magicien) cherche le Grimoire [📖]\n", mesHeros[i].pseudo);
        if(i == 3) printf("- %s (Voleur) cherche la Dague de sommeil [🔪]\n", mesHeros[i].pseudo);
    }
    printf("N'oubliez pas de trouver au moins un Tresor [💰] !\n\n");


    Case laGrille[5][5]; // Je genere ma grille 
    initialisation(laGrille); // Toutes les cartes sont bien cachees avec '?'
    afficherMenuAccueil(); 

    int jeuTermine = 0; // 0 = le jeu continue, 1 = quelqu'un a gagné
    int tourActuel = 0; // Permet de savoir à qui c'est le tour (0 = Joueur 1, 1 = Joueur 2, etc.)
    while (jeuTermine == 0){
        int finDeTour = 0;
        // 1. Annonce du joueur
        printf("\n====================================\n");
        printf(" C'est au tour de %s !\n", mesHeros[tourActuel].pseudo);
        printf("====================================\n");

        // 2. Le joueur choisit son arme avant de bouger
        mesHeros[tourActuel].armeActive = choisirArme() ; 
        printf("%s s'equipe de l'arme n°%d...\n", mesHeros[tourActuel].pseudo, mesHeros[tourActuel].armeActive);

        // 3. Afficher le plateau pour ce joueur
        afficherPlateau(laGrille, mesHeros[tourActuel]);


        // 4. Le menu de déplacement (Entrée forcée selon le PDF)
        int direction = 0;
        int vientDeSeTeleporter = 0; 

        if (mesHeros[tourActuel].peutTeleporter == 1) {
            printf("\n🌀 OU VEUX-TU TE TELEPORTER ? (Cases cachees uniquement)\n");
            printf("Ligne (0-4) : ");
            scanf("%d", &mesHeros[tourActuel].ligne);
            printf("Colonne (0-4) : ");
            scanf("%d", &mesHeros[tourActuel].colonne);

            mesHeros[tourActuel].peutTeleporter = 0; 
            vientDeSeTeleporter = 1;
        }
        
        // On met TOUTE la marche à pied à l'intérieur de ce if !
        if (vientDeSeTeleporter == 0) { 
            
            if (mesHeros[tourActuel].ligne == -1) {
                printf("\n%s est au Nord. Entree automatique vers le Bas.\n", mesHeros[tourActuel].pseudo);
                direction = 2; 
            } 
            else if (mesHeros[tourActuel].ligne == 5) {
                printf("\n%s est au Sud. Entree automatique vers le Haut.\n", mesHeros[tourActuel].pseudo);
                direction = 1; 
            } 
            else if (mesHeros[tourActuel].colonne == -1) {
                printf("\n%s est a l'Ouest. Entree automatique vers la Droite.\n", mesHeros[tourActuel].pseudo);
                direction = 4; 
            } 
            else if (mesHeros[tourActuel].colonne == 5) {
                printf("\n%s est a l'Est. Entree automatique vers la Gauche.\n", mesHeros[tourActuel].pseudo);
                direction = 3; 
            } 
            else {
                printf("\n--- OU VEUX-TU ALLER ? ---\n");
                printf("1: Haut ^\n2: Bas v\n3: Gauche <\n4: Droite >\n");
                printf("Ton choix : ");
                scanf("%d", &direction);
            }

            if(direction == 1){ 
                if(mesHeros[tourActuel].ligne > 0 || mesHeros[tourActuel].ligne == 5) {
                    mesHeros[tourActuel].ligne--; 
                } else {
                    printf("🛑 Impossible ! Il y a un mur au Nord.\n");
                }
            }
            else if(direction == 2){ 
                if(mesHeros[tourActuel].ligne < 4 || mesHeros[tourActuel].ligne == -1) {
                    mesHeros[tourActuel].ligne++; 
                } else {
                    printf("🛑 Impossible ! Il y a un mur au Sud.\n");
                }
            }
            else if(direction == 3) { 
                if(mesHeros[tourActuel].colonne > 0 || mesHeros[tourActuel].colonne == 5) {
                    mesHeros[tourActuel].colonne--; 
                } else {
                    printf("🛑 Impossible ! Il y a un mur a l'Ouest.\n");
                }
            }
            else if(direction == 4){ 
                if(mesHeros[tourActuel].colonne < 4 || mesHeros[tourActuel].colonne == -1) {
                    mesHeros[tourActuel].colonne++;
                } else {
                    printf("🛑 Impossible ! Il y a un mur a l'Est.\n");
                }
            }
        } 

        if (vientDeSeTeleporter == 1) {
            printf("✨ %s apparait magiquement sur la nouvelle case !\n", mesHeros[tourActuel].pseudo);
        } else {
            printf("👣 %s avance d'une case...\n", mesHeros[tourActuel].pseudo);
        }

        if (mesHeros[tourActuel].ligne >= 0 && mesHeros[tourActuel].ligne < 5 && 
            mesHeros[tourActuel].colonne >= 0 && mesHeros[tourActuel].colonne < 5) {
            
            // On retourne la carte !
            laGrille[mesHeros[tourActuel].ligne][mesHeros[tourActuel].colonne].estCachee = 0;
            
            // On réaffiche le plateau pour voir ce qui se cachait en dessous
            afficherPlateau(laGrille, mesHeros[tourActuel]);
            
            // verification du contenu de la case  

            // 1. SI C'EST UN MONSTRE
            if (strcmp(laGrille[mesHeros[tourActuel].ligne][mesHeros[tourActuel].colonne].typeContenu, "basilic") == 0 ||
                strcmp(laGrille[mesHeros[tourActuel].ligne][mesHeros[tourActuel].colonne].typeContenu, "zombie") == 0 ||
                strcmp(laGrille[mesHeros[tourActuel].ligne][mesHeros[tourActuel].colonne].typeContenu, "troll") == 0 ||
                strcmp(laGrille[mesHeros[tourActuel].ligne][mesHeros[tourActuel].colonne].typeContenu, "harpie") == 0) {
                
                printf("😱 OH NON ! Un monstre se cache ici !\n");
              
                int aGagne = 0 ;// On part du principe que le joueur perd (0 = mort, 1 = survie)
                char monstre[20];
                strcpy(monstre, laGrille[mesHeros[tourActuel].ligne][mesHeros[tourActuel].colonne].typeContenu); // On copie le nom
                int arme = mesHeros[tourActuel].armeActive; // On récupère le numéro de l'arme

                aGagne = resoudreCombat(monstre,arme) ; 


                if(aGagne== 1){
                    printf("⚔️ BRAVO ! Tu as utilise la bonne arme pour tuer le %s !\n", monstre);
                    // Le monstre disparaît
                    strcpy(laGrille[mesHeros[tourActuel].ligne][mesHeros[tourActuel].colonne].typeContenu, "estvide");
                }
                else {
                    printf("☠️ AIE ! Ton arme est inefficace. Tu es mort...\n");
                    
                    // 1. On le renvoie à sa position de départ en fonction de son numéro
                    if(tourActuel == 0) { 
                        mesHeros[tourActuel].ligne = -1; mesHeros[tourActuel].colonne = 2; 
                    }
                    else if(tourActuel == 1) { 
                        mesHeros[tourActuel].ligne = 5; mesHeros[tourActuel].colonne = 2; 
                    }
                    else if(tourActuel == 2) { 
                        mesHeros[tourActuel].ligne = 2; mesHeros[tourActuel].colonne = -1; 
                    }
                    else if(tourActuel == 3) { 
                        mesHeros[tourActuel].ligne = 2; mesHeros[tourActuel].colonne = 5; 
                    }

                    // 2. On recache TOUT LE PLATEAU (La règle du Memory !)
                    printf("🌫️ Le brouillard recouvre le labyrinthe...\n");
                    for(int l = 0; l < 5; l++) {
                        for(int c = 0; c < 5; c++) {
                            laGrille[l][c].estCachee = 1; 
                        }
                    }
                    finDeTour = 1;
                }
            }
            // 2. SI C'EST LE TRESOR
            else if(strcmp(laGrille[mesHeros[tourActuel].ligne][mesHeros[tourActuel].colonne].typeContenu, "tresor") == 0) {
                printf("💰 INCROYABLE ! %s a trouve le coffre au tresor ! C'EST GAGNE !\n", mesHeros[tourActuel].pseudo);
                mesHeros[tourActuel].tresorTrouve = 1;
                if(mesHeros[tourActuel].armeAntiqueTrouvee ==1){
                    printf("VICTOIRE ! %s possede son arme ET un tresor. C'EST GAGNE !\n", mesHeros[tourActuel].pseudo);

                    jeuTermine =1 ;
                }
                else{
                    printf("Il ne te manque plus que ton arme antique pour gagner !\n");
                }
            
            }
            // 3. SI C'EST UNE ARME ANTIQUE
            else if(strcmp(laGrille[mesHeros[tourActuel].ligne][mesHeros[tourActuel].colonne].typeContenu, "epee_feu") == 0 ||
                     strcmp(laGrille[mesHeros[tourActuel].ligne][mesHeros[tourActuel].colonne].typeContenu, "baton_controle") == 0 ||
                     strcmp(laGrille[mesHeros[tourActuel].ligne][mesHeros[tourActuel].colonne].typeContenu, "grimoire") == 0 ||
                     strcmp(laGrille[mesHeros[tourActuel].ligne][mesHeros[tourActuel].colonne].typeContenu, "dague_sommeil") == 0) {

                char armeRecherchee[20];
                if(tourActuel == 0){
                    strcpy(armeRecherchee, "epee_feu");
                }
                else if(tourActuel==1){
                    strcpy(armeRecherchee, "baton_controle");
                }
                else if(tourActuel== 2){
                    strcpy(armeRecherchee, "grimoire");
                }
                else{
                    strcpy(armeRecherchee, "dague_sommeil");
                }
                // Est-ce que l'arme trouvée est bien LA SIENNE ?
                if (strcmp(laGrille[mesHeros[tourActuel].ligne][mesHeros[tourActuel].colonne].typeContenu, armeRecherchee) == 0) {
                    printf("✨ MAGNIFIQUE ! %s a trouve SON arme antique : %s !\n", mesHeros[tourActuel].pseudo, armeRecherchee);
                    mesHeros[tourActuel].armeAntiqueTrouvee = 1; // On note qu'il a son arme

                    if (mesHeros[tourActuel].tresorTrouve == 1) { // S'il a AUSSI le trésor
                        printf("🏆 VICTOIRE TOTALE ! %s possede son arme ET un tresor. C'EST GAGNE !\n", mesHeros[tourActuel].pseudo);
                        jeuTermine = 1;
                    }
                    else{
                        printf("Il ne te manque plus qu'un tresor pour gagner !\n");
                    }
                }
                else{
                    printf("Dommage, c'est l'arme antique d'un autre aventurier. Tu passes ton chemin...\n");
                }
            }
            // 4. SI C'EST UN PORTAIL
            else if(strcmp(laGrille[mesHeros[tourActuel].ligne][mesHeros[tourActuel].colonne].typeContenu, "portail") == 0) {
                printf("🌀 PORTAIL MAGIQUE ! %s peut se teleporter n'importe ou au prochain tour !\n", mesHeros[tourActuel].pseudo);
                mesHeros[tourActuel].peutTeleporter = 1; 
            }
            // 5. SI C'EST UN TOTEM DE TRANSMUTATION

            else if(strcmp(laGrille[mesHeros[tourActuel].ligne][mesHeros[tourActuel].colonne].typeContenu, "totem") == 0) {
                executerTotem(laGrille, mesHeros, tourActuel);
                finDeTour = 1;
            }

            // 6. SI C'EST VIDE
            else {
                printf("Ouf, la voie est libre.\n");
            }
        }




        // --- FIN DU TOUR --- (Seulement si le jeu n'est pas terminé)
        if (jeuTermine == 0 && finDeTour == 1) {
            tourActuel = tourActuel + 1;
            if(tourActuel == nbJoueurs) {
                tourActuel = 0; 
            }
        }

    }
    // Révélation finale de tout le plateau 
    printf("\n--- TOUTES LES CARTES SONT REVELEES ! ---\n");
    for(int l = 0; l < 5; l++) {
        for(int c = 0; c < 5; c++) {
            laGrille[l][c].estCachee = 0;
        }
    }
    // On affiche une dernière fois pour que tout le monde voie
    afficherPlateau(laGrille, mesHeros[0]); 
    printf("\nBravo à %s ! --- FIN DE LA PARTIE ---\n", mesHeros[tourActuel].pseudo);

    sauvegarderScores(mesHeros, nbJoueurs, mesHeros[tourActuel].pseudo);    
    return 0;
}
