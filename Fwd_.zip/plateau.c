#include <stdio.h>
#include <string.h> // pour strcpy
#include <stdlib.h>  // Pour srand() et rand()
#include <time.h>    // Pour time()
#include "structure.h" // case et joueur
#include "plateau.h" // les fonction 

void initialisation(Case grille[5][5]){
    // 1. On crée la liste de tout ce qu'on veut mettre dans le donjon (25 objets)
    char *objets[25] = {
        "basilic", "zombie", "troll", "harpie",
        "basilic", "zombie", "troll", "harpie",
        "tresor", "tresor", // <--- LA VIRGULE MAGIQUE EST ICI !
        "epee_feu", "baton_controle", "grimoire", "dague_sommeil",
        "portail", "totem", "totem", 
        "estvide", "estvide", "estvide", "estvide",
        "estvide", "estvide", "estvide", "estvide" // (Pas besoin de virgule au tout dernier)
    };
    srand(time(NULL));
    for (int i = 0; i < 25; i++) { // on melange la liste 
        int j = rand() % 25;
        char *temp = objets[i];
        objets[i] = objets[j];
        objets[j] = temp;
    }

    int k = 0 ; // On remplit la grille avec les objets mélangés
    for (int l = 0; l < 5; l++) {
        for (int c = 0; c < 5; c++) {
            strcpy(grille[l][c].typeContenu, objets[k]);
            grille[l][c].estCachee = 1; // Au début, tout est caché sous un '?'
            k++;
        }
    }
}

void afficherPlateau(Case grille[5][5], Joueur jActuel){
    printf("\n ------le donjon-----\n"); 
    for(int l=0 ; l<5; l++){
        for(int c=0 ; c<5 ; c++){ // on parcours la crille de jeu 
            // 1. On vérifie si le JOUEUR est sur cette case
            if(jActuel.ligne == l && jActuel.colonne == c){
                // On affiche la première lettre de son pseudo en Majuscule
                // On met des étoiles pour bien le voir : *S*
                printf("[%c]", jActuel.pseudo[0]);
            }
            // 2. Sinon, si la case est déjà découverte (estCachee == 0)
            else if(grille[l][c].estCachee == 0){
                
                // --- LES TRESORS ---
                if(strcmp(grille[l][c].typeContenu, "tresor") == 0) { printf("[💰]"); }
                
                // --- LES MONSTRES ---
                else if(strcmp(grille[l][c].typeContenu, "zombie") == 0) { printf("[🧟]"); }
                else if(strcmp(grille[l][c].typeContenu, "basilic") == 0) { printf("[🐍]"); }
                else if(strcmp(grille[l][c].typeContenu, "troll") == 0) { printf("[👹]"); }
                else if(strcmp(grille[l][c].typeContenu, "harpie") == 0) { printf("[🦅]"); }
                
                // --- LES ARMES ANTIQUES ---
                else if(strcmp(grille[l][c].typeContenu, "epee_feu") == 0) { printf("[🗡️]"); }
                else if(strcmp(grille[l][c].typeContenu, "baton_controle") == 0) { printf("[🪄]"); }
                else if(strcmp(grille[l][c].typeContenu, "grimoire") == 0) { printf("[📖]"); }
                else if(strcmp(grille[l][c].typeContenu, "dague_sommeil") == 0) { printf("[🔪]"); }
                
                // --- LES OBJETS MAGIQUES ---
                else if(strcmp(grille[l][c].typeContenu, "portail") == 0) { printf("[🌀]"); }
                else if(strcmp(grille[l][c].typeContenu, "totem") == 0) { printf("[🗿]"); }
                
                // --- SI LA CASE EST VIDE (Monstre tué) ---
                else if(strcmp(grille[l][c].typeContenu, "estvide") == 0) { printf("[  ]"); }
            }
            else {
                printf("[🎴]"); // Tu peux mettre [?] ou [🚪] ou [🌫️]
            }


        }
        printf("\n");
    }
}
